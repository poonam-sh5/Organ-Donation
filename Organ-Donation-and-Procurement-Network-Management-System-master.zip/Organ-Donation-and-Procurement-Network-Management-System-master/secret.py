import secrets
secret_key = secrets.token_urlsafe(16)
