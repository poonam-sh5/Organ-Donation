insert into User values
(1,'Name-1',1973-15-04,1,'NIL','Baker Street','Mumbai','Maharashtra');